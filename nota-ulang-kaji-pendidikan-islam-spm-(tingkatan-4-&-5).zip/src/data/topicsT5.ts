export interface SubtopicT5 {
  id: string;
  badge?: string;
  title: string;
  contentHtml?: string;
}

export interface TopicItemT5 {
  id: string;
  number: number;
  field: "al-quran" | "hadis" | "akidah" | "fikah" | "sirah" | "akhlak";
  fieldLabel: string;
  title: string;
  summary?: string;
  subtopics?: SubtopicT5[];
  directContentHtml?: string;
}

export const topicsDataT5: TopicItemT5[] = [
  // ==========================================
  // 1. BIDANG AL-QURAN
  // ==========================================
  {
    id: "t5-p3",
    number: 3,
    field: "al-quran",
    fieldLabel: "Bidang Al-Quran (Tajwid)",
    title: "Pelajaran 3: Hukum Tajwid: Bacaan 'Ra', Wakaf dan Ibtida'",
    summary: "Hukum bacaan Ra' (Tafkhim & Tarqiq), 5 tanda wakaf, 4 jenis wakaf (Tam, Kafi, Hasan, Qabih), serta kaedah Ibtida' Hasan & Qabih.",
    subtopics: [
      {
        id: "t5-p3-u1",
        badge: "UNIT 1",
        title: "Unit 1: Hukum Bacaan 'Ra' (حكوم باجاءن 'ر')",
        contentHtml: `
          <div class="mb-4">
            <p>Cara bacaan huruf "Ra" terbahagi kepada dua:</p>
            <ul>
              <li><b>Tafkhim (تَفْخِيم - Tebal):</b> Dibaca dengan menebalkan sebutan huruf "Ra".</li>
              <li><b>Tarqiq (تَرْقِيق - Nipis):</b> Dibaca dengan menipiskan sebutan huruf "Ra".</li>
            </ul>
          </div>

          <h4 class="text-base font-bold text-[#ffd447] mt-5 mb-2 border-b border-stone-600 pb-1">
            🟩 Unit 1.1: Keadaan Ra Dibaca Tafkhim (Tebal)
          </h4>
          <p class="text-sm text-slate-300 mb-3">Huruf "Ra" dibaca tebal dalam keadaan berikut:</p>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th style="width: 50px;">Bil</th>
                  <th>Keadaan Huruf Ra'</th>
                  <th>Contoh Kalimah & Dalil</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><b>1</b></td>
                  <td>Ra berbaris Fathah (رَ) atau Dammah (رُ)</td>
                  <td><span class="arabic-text">رَبَّنَا</span> (Surah Ali 'Imran: 8)<br><span class="arabic-text">يَنصُرُونَ</span> (Surah al-A'raf: 192)</td>
                </tr>
                <tr>
                  <td><b>2</b></td>
                  <td>Ra Sakinah (ْر) asal dan huruf sebelumnya berbaris Fathah atau Dammah</td>
                  <td><span class="arabic-text">وَإِذْ رَفَعَ</span> (Surah al-Baqarah: 127)<br><span class="arabic-text">فُرْقَانًا</span> (Surah al-Anfal: 29)</td>
                </tr>
                <tr>
                  <td><b>3</b></td>
                  <td>
                    Ra Sakinah, huruf sebelumnya berbaris Kasrah dan selepasnya terdapat <b>huruf Isti'la' berbaris Fathah</b> dalam satu kalimah.<br>
                    <span class="text-xs text-amber-200/90 mt-1 block"><b>7 Huruf Isti'la':</b> خ, ص, ض, غ, ط, ق, ظ (dihimpunkan dalam lafaz <b>خَصَّ ضَغْطٍ قِظْ</b>).</span>
                  </td>
                  <td><span class="arabic-text">مِن كُلِّ فِرْقَةٍ</span> (Surah at-Taubah: 122)<br><span class="arabic-text">فِي قِرْطَاسٍ</span> (Surah al-An'am: 7)</td>
                </tr>
                <tr>
                  <td><b>4</b></td>
                  <td>Ra Sakinah terletak di awal kalimah selepas <b>Hamzah Wasal</b></td>
                  <td><span class="arabic-text">ارْجِعُوا</span> (Surah Yusuf: 81)<br><span class="arabic-text">ارْكَبُوا</span> (Surah Hud: 41)</td>
                </tr>
                <tr>
                  <td><b>5</b></td>
                  <td>Ra Sakinah dan huruf sebelumnya berbaris <b>Kasrah Asli</b> atau <b>Kasrah 'Aridah</b> (mendatang)</td>
                  <td><span class="arabic-text">رَّبِّ ارْحَمْهُمَا</span> (Surah al-Isra': 24)<br><span class="arabic-text">إِلَّا مَنِ ارْتَضَىٰ</span> (Surah al-Jinn: 27)</td>
                </tr>
                <tr>
                  <td><b>6</b></td>
                  <td>
                    Ra berbaris dibaca secara <b>Waqaf</b> apabila:
                    <ul class="text-xs mt-1 space-y-1">
                      <li>• Huruf sebelumnya berbaris Fathah atau Dammah (selain Ya Sakinah).</li>
                      <li>• Huruf sebelumnya Alif Sakinah atau Wau Sakinah.</li>
                      <li>• Huruf sebelumnya Sakinah yang didahului huruf berbaris Fathah atau Dammah.</li>
                    </ul>
                  </td>
                  <td>
                    <span class="arabic-text">الْكَوْثَرَ</span> (Surah al-Kautsar: 1)<br>
                    <span class="arabic-text">الْأُمُورُ</span> (Surah al-Baqarah: 167)<br>
                    <span class="arabic-text">خُسْرٍ</span> (Surah al-'Asr: 2)
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <h4 class="text-base font-bold text-[#2fd17a] mt-6 mb-2 border-b border-stone-600 pb-1">
            🟨 Unit 1.2: Keadaan Ra Dibaca Tarqiq (Nipis)
          </h4>
          <p class="text-sm text-slate-300 mb-3">Huruf "Ra" dibaca nipis dalam keadaan berikut:</p>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th style="width: 50px;">Bil</th>
                  <th>Keadaan Huruf Ra'</th>
                  <th>Contoh Kalimah & Dalil</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><b>1</b></td>
                  <td>Ra berbaris Kasrah (رِ) asli di awal, tengah, atau akhir kalimah</td>
                  <td>
                    <span class="arabic-text">رِزْقٌ كَرِيمٌ</span> (Surah al-Anfal: 4)<br>
                    <span class="arabic-text">أَبْصَارِهِمْ غِشَاوَةٌ</span> (Surah al-Baqarah: 7)<br>
                    <span class="arabic-text">أَصْحَابُ الْحِجْرِ</span> (Surah al-Hijr: 80)
                  </td>
                </tr>
                <tr>
                  <td><b>2</b></td>
                  <td>Ra berbaris Kasrah 'Aridah (mendatang) dalam dua kalimah yang dibaca secara Wasal</td>
                  <td>
                    <span class="arabic-text">وَاذْكُرِ اسْمَ</span> (Surah al-Muzzammil: 8)<br>
                    <span class="arabic-text">وَبَشِّرِ الصَّابِرِينَ</span> (Surah al-Baqarah: 155)
                  </td>
                </tr>
                <tr>
                  <td><b>3</b></td>
                  <td>Ra Sakinah dan huruf sebelumnya berbaris Kasrah dalam satu kalimah dan selepasnya <b>tidak terdapat huruf Isti'la'</b></td>
                  <td>
                    <span class="arabic-text">مِرْيَةٍ</span> (Surah Hud: 17)<br>
                    <span class="arabic-text">فِرْعَوْنَ</span> (Surah al-Baqarah: 50)
                  </td>
                </tr>
                <tr>
                  <td><b>4</b></td>
                  <td>
                    Ra berbaris dibaca secara <b>Waqaf</b> apabila:
                    <ul class="text-xs mt-1 space-y-1">
                      <li>• Huruf sebelumnya berbaris Kasrah.</li>
                      <li>• Huruf sebelumnya Ya Sakinah.</li>
                      <li>• Huruf sebelumnya Sakinah yang didahului huruf berbaris Kasrah.</li>
                    </ul>
                  </td>
                  <td>
                    <span class="arabic-text">الْمَقَابِرَ</span> (Surah at-Takatsur: 2)<br>
                    <span class="arabic-text">قَدِيرٌ</span> (Surah al-Ma'idah: 40)<br>
                    <span class="arabic-text">السِّحْرُ</span> (Surah Yunus: 81)
                  </td>
                </tr>
                <tr>
                  <td><b>5</b></td>
                  <td>
                    <b>Ra yang dibaca secara Imalah (إمالة)</b><br>
                    <span class="text-xs text-amber-200/90 block mt-1">Imalah ialah sebutan pertengahan antara bunyi Fathah dengan Kasrah. Terdapat pada <b>satu tempat sahaja</b> dalam al-Quran.</span>
                  </td>
                  <td>
                    <span class="arabic-text">مَجْرٰىهَا</span> dalam ayat:<br>
                    <span class="arabic-text">بِسْمِ اللَّهِ مَجْرٰىهَا وَمُرْسَاهَا</span> (Surah Hud: 41)
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        `
      },
      {
        id: "t5-p3-u2",
        badge: "UNIT 2",
        title: "Unit 2: Tanda dan Jenis Waqaf (تندا دان جنيس وقف)",
        contentHtml: `
          <div class="mb-4">
            <p><b>Maksud Waqaf:</b> Memberhentikan bacaan di akhir kalimah untuk bernafas dengan tujuan mengambil bacaan semula.</p>
          </div>

          <h4 class="text-base font-bold text-[#ffd447] mt-4 mb-2 border-b border-stone-600 pb-1">
            🟩 Unit 2.1: Tanda-Tanda Waqaf
          </h4>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th style="width: 90px;">Simbol</th>
                  <th>Nama Tanda Waqaf</th>
                  <th>Keterangan / Hukum Cara Berhenti</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><span class="pixel-font text-lg text-[#ffd447] font-bold">م</span></td>
                  <td><b>Waqaf Lazim</b></td>
                  <td>Dikalafkan / wajib berhenti.</td>
                </tr>
                <tr>
                  <td><span class="pixel-font text-lg text-[#ffd447] font-bold">∴ ∴</span></td>
                  <td><b>Waqaf Mu'anaqah / Muraqabah</b></td>
                  <td>Harus berhenti pada salah satu tempat sahaja (bukan kedua-duanya).</td>
                </tr>
                <tr>
                  <td><span class="pixel-font text-lg text-[#ffd447] font-bold">قلى</span></td>
                  <td><b>Waqaf Aula</b></td>
                  <td>Berhenti adalah lebih utama daripada meneruskan bacaan.</td>
                </tr>
                <tr>
                  <td><span class="pixel-font text-lg text-[#ffd447] font-bold">ج</span></td>
                  <td><b>Waqaf Ja'iz</b></td>
                  <td>Harus berhenti atau meneruskan bacaan (sama taraf).</td>
                </tr>
                <tr>
                  <td><span class="pixel-font text-lg text-[#ffd447] font-bold">صلى</span></td>
                  <td><b>Wasal Aula</b></td>
                  <td>Menyambung bacaan adalah lebih utama daripada berhenti.</td>
                </tr>
              </tbody>
            </table>
          </div>

          <h4 class="text-base font-bold text-[#2fd17a] mt-6 mb-2 border-b border-stone-600 pb-1">
            🟨 Unit 2.2: Jenis-Jenis Waqaf
          </h4>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Jenis Waqaf</th>
                  <th>Maksud & Huraian</th>
                  <th>Cara Bacaan & Contoh</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><b>1. Waqaf Tam<br>(وقف تام)</b></td>
                  <td>Waqaf pada ayat yang telah sempurna maknanya, serta tidak mempunyai kaitan dengan ayat selepasnya dari sudut lafaz dan makna.</td>
                  <td>
                    <b>Cara Bacaan:</b> Berhenti pada kalimah tersebut dan memulakan bacaan pada kalimah berikutnya.<br>
                    <span class="text-xs text-slate-300"><b>Contoh:</b> Surah al-Baqarah: 5–6</span>
                  </td>
                </tr>
                <tr>
                  <td><b>2. Waqaf Kafi<br>(وقف كافي)</b></td>
                  <td>Waqaf pada ayat yang telah sempurna maknanya, tetapi mempunyai kaitan dengan ayat selepasnya dari sudut makna, bukan lafaz.</td>
                  <td>
                    <b>Cara Bacaan:</b> Berhenti pada kalimah tersebut dan memulakan bacaan pada kalimah berikutnya.<br>
                    <span class="text-xs text-slate-300"><b>Contoh:</b> Surah al-Baqarah: 6–7</span>
                  </td>
                </tr>
                <tr>
                  <td><b>3. Waqaf Hasan<br>(وقف حسن)</b></td>
                  <td>Waqaf pada ayat yang telah sempurna maknanya, tetapi mempunyai kaitan dengan ayat selepasnya dari sudut lafaz dan makna.</td>
                  <td>
                    <b>Cara Bacaan:</b> Berhenti pada kalimah tersebut, dan tidak memulakan bacaan pada kalimah berikutnya kecuali jika berada di akhir ayat (رأس الآية).<br>
                    <span class="text-xs text-slate-300"><b>Contoh:</b> Surah al-Fatihah: 2</span>
                  </td>
                </tr>
                <tr>
                  <td><b>4. Waqaf Qabih<br>(وقف قبيح)</b></td>
                  <td>Waqaf pada ayat yang mengubah makna sebenar atau tidak sempurna makna kerana mempunyai kaitan dengan kalimah selepasnya dari sudut lafaz dan makna.</td>
                  <td>
                    <b>Cara Bacaan:</b> Tidak harus berhenti pada kalimah tersebut secara sengaja.<br>
                    <span class="text-xs text-amber-200"><b>Contoh:</b> Surah an-Nisa': 43 (<span class="arabic-text">يَـٰأَيُّهَا ٱلَّذِينَ ءَامَنُوا۟ لَا تَقْرَبُوا۟ ٱلصَّلَوٰةَ ...</span> tanpa sambung)</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        `
      },
      {
        id: "t5-p3-u3",
        badge: "UNIT 3",
        title: "Unit 3: Jenis Ibtida' (جنيس ابتداء)",
        contentHtml: `
          <div class="mb-4">
            <p><b>Maksud Ibtida':</b> Memulakan bacaan Al-Quran selepas waqaf.</p>
          </div>

          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Jenis Ibtida'</th>
                  <th>Maksud & Huraian</th>
                  <th>Hukum</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><b>1. Ibtida' Hasan<br>(ابتداء حسن)</b></td>
                  <td>Memulakan bacaan pada kalimah yang dapat difahami maknanya serta tidak bersalahan dengan maksud yang dikehendaki Allah SWT.</td>
                  <td><span class="badge-tag bg-emerald-800 text-emerald-100 font-bold px-2 py-0.5 text-xs">HARUS</span></td>
                </tr>
                <tr>
                  <td><b>2. Ibtida' Qabih<br>(ابتداء قبيح)</b></td>
                  <td>Memulakan bacaan pada kalimah yang tidak menyampaikan maksud yang sebenar atau boleh mengubah makna yang dikehendaki Allah SWT.</td>
                  <td><span class="badge-tag bg-red-900 text-red-100 font-bold px-2 py-0.5 text-xs">TIDAK HARUS</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        `
      }
    ]
  },
  {
    id: "t5-p4",
    number: 4,
    field: "al-quran",
    fieldLabel: "Bidang Al-Quran",
    title: "Pelajaran 4: Ciri-Ciri Mukmin Berjaya (Surah al-Mu'minun: 1–11)",
    summary: "Hafazan dan kefahaman 7 sifat orang beriman yang mewarisi Syurga Firdaus mengikut Surah al-Mu'minun: 1–11.",
    subtopics: [
      {
        id: "t5-p4-u1",
        badge: "UNIT 1",
        title: "Unit 1: Hafazan Surah Al-Mu'minun (Ayat 1–11)",
        contentHtml: `
          <div class="mb-4">
            <span class="field-label text-xs">PANDUAN HAFAZAN TERTIB & FASIH</span>
            <p class="text-sm text-slate-300 mt-2">
              Unit ini menekankan pembacaan dan hafazan ayat 1 hingga 11 daripada Surah Al-Mu'minun secara betul, lancar, bertajwid, dan fasih.
            </p>
          </div>

          <div class="arabic-box my-4 p-4 bg-[#14243f] border-2 border-[#1c1f24] text-right space-y-3">
            <p class="text-xl leading-loose font-serif text-[#ffd447]" dir="rtl">
              بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
            </p>
            <p class="text-lg leading-loose font-serif text-white" dir="rtl">
              قَدْ أَفْلَحَ الْمُؤْمِنُونَ ﴿١﴾ الَّذِينَ هُمْ فِي صَلَاتِهِمْ خَاشِعُونَ ﴿٢﴾ وَالَّذِينَ هُمْ عَنِ اللَّغْوِ مُعْرِضُونَ ﴿٣﴾ وَالَّذِينَ هُمْ لِلزَّكَاةِ فَاعِلُونَ ﴿٤﴾ وَالَّذِينَ هُمْ لِفُرُوجِهِمْ حَافِظُونَ ﴿٥﴾ إِلَّا عَلَىٰ أَزْوَاجِهِمْ أَوْ مَا مَلَكَتْ أَيْمَانُهُمْ فَإِنَّهُمْ غَيْرُ مَلُومِينَ ﴿٦﴾ فَمَنِ ابْتَغَىٰ وَرَاءَ ذَٰلِكَ فَأُولَـٰئِكَ هُمُ الْعَادُونَ ﴿٧﴾ وَالَّذِينَ هُمْ لِأَمَانَاتِهِمْ وَعَهْدِهِمْ رَاعُونَ ﴿٨﴾ وَالَّذِينَ هُمْ عَلَىٰ صَلَوَاتِهِمْ يُحَافِظُونَ ﴿٩﴾ أُولَـٰئِكَ هُمُ الْوَارِثُونَ ﴿١٠﴾ الَّذِينَ يَرِثُونَ الْفِرْدَوْسَ هُمْ فِيهَا خَالِدُونَ ﴿١١﴾
            </p>
          </div>

          <h4 class="text-base font-bold text-[#ffd447] mt-4 mb-2">Terjemahan Ayat Demi Ayat (Ayat 1–11):</h4>
          <div class="space-y-2 text-sm text-slate-200">
            <div class="p-2.5 bg-[#1f2328] border-l-4 border-[#2fd17a]">
              <strong class="text-amber-300">Ayat 1:</strong> Sesungguhnya berjayalah orang-orang yang beriman,
            </div>
            <div class="p-2.5 bg-[#1f2328] border-l-4 border-[#2fd17a]">
              <strong class="text-amber-300">Ayat 2:</strong> Iaitu mereka yang khusyuk dalam sembahyangnya,
            </div>
            <div class="p-2.5 bg-[#1f2328] border-l-4 border-[#2fd17a]">
              <strong class="text-amber-300">Ayat 3:</strong> Dan mereka yang menjauhkan diri daripada perbuatan dan perkataan yang sia-sia,
            </div>
            <div class="p-2.5 bg-[#1f2328] border-l-4 border-[#2fd17a]">
              <strong class="text-amber-300">Ayat 4:</strong> Dan mereka yang berusaha membersihkan hartanya dengan menunaikan zakat,
            </div>
            <div class="p-2.5 bg-[#1f2328] border-l-4 border-[#2fd17a]">
              <strong class="text-amber-300">Ayat 5:</strong> Dan mereka yang menjaga kehormatannya,
            </div>
            <div class="p-2.5 bg-[#1f2328] border-l-4 border-[#2fd17a]">
              <strong class="text-amber-300">Ayat 6:</strong> Kecuali kepada isterinya atau hamba sahayanya, maka sesungguhnya mereka tidak tercela,
            </div>
            <div class="p-2.5 bg-[#1f2328] border-l-4 border-[#2fd17a]">
              <strong class="text-amber-300">Ayat 7:</strong> Kemudian, sesiapa yang mengingini selain dari yang demikian, maka merekalah orang-orang yang melampaui batas,
            </div>
            <div class="p-2.5 bg-[#1f2328] border-l-4 border-[#2fd17a]">
              <strong class="text-amber-300">Ayat 8:</strong> Dan mereka yang menjaga amanah dan janjinya,
            </div>
            <div class="p-2.5 bg-[#1f2328] border-l-4 border-[#2fd17a]">
              <strong class="text-amber-300">Ayat 9:</strong> Dan mereka yang tetap memelihara sembahyangnya,
            </div>
            <div class="p-2.5 bg-[#1f2328] border-l-4 border-[#2fd17a]">
              <strong class="text-amber-300">Ayat 10:</strong> Mereka itulah orang-orang yang berhak mewarisi,
            </div>
            <div class="p-2.5 bg-[#1f2328] border-l-4 border-[#2fd17a]">
              <strong class="text-amber-300">Ayat 11:</strong> Yang akan mewarisi Syurga Firdaus; mereka kekal di dalamnya.
            </div>
          </div>
        `
      },
      {
        id: "t5-p4-u2",
        badge: "UNIT 2",
        title: "Unit 2: Kefahaman Surah (7 Ciri Mukmin Berjaya)",
        contentHtml: `
          <div class="mb-4">
            <p class="text-sm text-slate-300">
              Dalam ayat 1–11 Surah Al-Mu'minun, Allah SWT menyenaraikan <b>7 ciri utama</b> bagi golongan mukmin yang mendapat kejayaan:
            </p>
          </div>

          <div class="space-y-4">
            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2">
                <span class="badge-tag bg-amber-500 text-stone-900 font-bold px-2 py-0.5 text-xs">CIRI 1</span>
                <h4 class="text-base font-bold text-white">1. Beriman kepada Allah SWT</h4>
              </div>
              <p class="text-sm text-slate-300 mt-2">
                <b>Huraian:</b> Orang yang sentiasa meyakini bahawa Allah SWT sahaja yang berhak disembah dengan melakukan segala suruhan-Nya dan meninggalkan segala larangan-Nya.
              </p>
            </div>

            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2">
                <span class="badge-tag bg-amber-500 text-stone-900 font-bold px-2 py-0.5 text-xs">CIRI 2</span>
                <h4 class="text-base font-bold text-white">2. Khusyuk dalam Solat</h4>
              </div>
              <p class="text-sm text-slate-300 mt-2">
                <b>Huraian:</b> Menumpukan sepenuh hati dan penghayatan dengan cara menenangkan anggota badan, memahami bacaan, serta perbuatan ketika mendirikan solat.
              </p>
            </div>

            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2">
                <span class="badge-tag bg-amber-500 text-stone-900 font-bold px-2 py-0.5 text-xs">CIRI 3</span>
                <h4 class="text-base font-bold text-white">3. Menjauhi Perbuatan dan Perkataan yang Sia-sia</h4>
              </div>
              <p class="text-sm text-slate-300 mt-2">
                <b>Huraian:</b> Menjauhkan diri daripada perbuatan dan perkataan yang tidak mendatangkan faedah atau perkara yang merosakkan akhlak.
              </p>
              
              <div class="grid sm:grid-cols-2 gap-3 mt-3">
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <strong class="text-xs text-[#ffd447] block mb-1">Contoh Perbuatan Sia-sia:</strong>
                  <ul class="list-disc pl-4 text-xs text-slate-200 space-y-1">
                    <li>Melepak</li>
                    <li>Merokok</li>
                    <li>Melalaikan masa dengan permainan video</li>
                  </ul>
                </div>

                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <strong class="text-xs text-[#ffd447] block mb-1">Contoh Perkataan Sia-sia:</strong>
                  <ul class="list-disc pl-4 text-xs text-slate-200 space-y-1">
                    <li>Mencarut</li>
                    <li>Bergosip</li>
                    <li>Berbual kosong ketika belajar</li>
                  </ul>
                </div>
              </div>
            </div>

            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2">
                <span class="badge-tag bg-amber-500 text-stone-900 font-bold px-2 py-0.5 text-xs">CIRI 4</span>
                <h4 class="text-base font-bold text-white">4. Menunaikan Zakat</h4>
              </div>
              <p class="text-sm text-slate-300 mt-2">
                <b>Huraian:</b> Mengeluarkan sebahagian harta tertentu untuk diberikan kepada golongan yang berhak menerima (seperti zakat fitrah dan zakat harta) mengikut syarat syarak.
              </p>
            </div>

            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2">
                <span class="badge-tag bg-amber-500 text-stone-900 font-bold px-2 py-0.5 text-xs">CIRI 5</span>
                <h4 class="text-base font-bold text-white">5. Menjaga Kehormatan Diri</h4>
              </div>
              <p class="text-sm text-slate-300 mt-2">
                <b>Huraian:</b> Menjaga dan mengelakkan diri daripada perkara yang diharamkan oleh syarak seperti zina, sumbang mahram, dan hubungan seks luar tabii.
              </p>
            </div>

            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2">
                <span class="badge-tag bg-amber-500 text-stone-900 font-bold px-2 py-0.5 text-xs">CIRI 6</span>
                <h4 class="text-base font-bold text-white">6. Menjaga Amanah dan Janji</h4>
              </div>
              <p class="text-sm text-slate-300 mt-2">
                <b>Huraian:</b> Menjaga tanggungjawab dalam setiap urusan, seperti dalam urusan pekerjaan, harta benda, kerahsiaan, dan janji.
              </p>
            </div>

            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2">
                <span class="badge-tag bg-amber-500 text-stone-900 font-bold px-2 py-0.5 text-xs">CIRI 7</span>
                <h4 class="text-base font-bold text-white">7. Sentiasa Memelihara Solat</h4>
              </div>
              <p class="text-sm text-slate-300 mt-2">
                <b>Huraian:</b> Menunaikan solat pada waktunya dengan menyempurnakan segala syarat dan rukunnya.
              </p>
            </div>
          </div>

          <!-- Ganjaran Mukmin Berjaya -->
          <div class="mt-6 p-4 bg-[#14243f] border-2 border-[#ffd447]">
            <h4 class="text-base font-bold text-[#ffd447] flex items-center gap-2">
              <span>🟨 Balasan / Ganjaran Mukmin Berjaya</span>
            </h4>
            <p class="text-sm text-slate-200 mt-2 leading-relaxed">
              Golongan yang memenuhi ketujuh-tujuh ciri di atas akan mendapat balasan yang amat mulia di akhirat, iaitu <b>mewarisi Syurga Firdaus</b> dan kekal di dalamnya selama-lamanya.
            </p>
          </div>

          <!-- Pengajaran Ayat -->
          <div class="mt-6 p-4 bg-[#1f2328] border-2 border-[#2fd17a]">
            <h4 class="text-base font-bold text-[#2fd17a] flex items-center gap-2">
              <span>🟧 Pengajaran Ayat (Surah al-Mu'minun: 1–11)</span>
            </h4>
            <p class="text-xs text-slate-300 mt-1 mb-3">Sebagai umat Islam, pengajaran yang boleh diambil daripada ayat ini ialah:</p>
            <ul class="space-y-2 text-sm text-slate-200">
              <li class="flex items-start gap-2">
                <span class="text-[#2fd17a] font-bold">1.</span>
                <span>Kita hendaklah <b>meningkatkan keimanan</b> kepada Allah SWT dengan melaksanakan suruhan-Nya dan meninggalkan larangan-Nya.</span>
              </li>
              <li class="flex items-start gap-2">
                <span class="text-[#2fd17a] font-bold">2.</span>
                <span>Kita hendaklah <b>menunaikan solat dengan khusyuk</b> agar menjadi hamba yang bertakwa.</span>
              </li>
              <li class="flex items-start gap-2">
                <span class="text-[#2fd17a] font-bold">3.</span>
                <span>Kita hendaklah <b>menjauhkan diri daripada perbuatan dan perkataan sia-sia</b> untuk meningkatkan kualiti kerja dan masa.</span>
              </li>
              <li class="flex items-start gap-2">
                <span class="text-[#2fd17a] font-bold">4.</span>
                <span>Kita hendaklah <b>berusaha menunaikan zakat</b> bagi membantu perkembangan ekonomi umat Islam.</span>
              </li>
              <li class="flex items-start gap-2">
                <span class="text-[#2fd17a] font-bold">5.</span>
                <span>Kita hendaklah <b>menjaga kehormatan diri</b> supaya terpelihara daripada penyakit dan perkara berbahaya.</span>
              </li>
              <li class="flex items-start gap-2">
                <span class="text-[#2fd17a] font-bold">6.</span>
                <span>Kita hendaklah <b>menjaga amanah dan janji</b> agar integriti Muslim sentiasa terpelihara.</span>
              </li>
              <li class="flex items-start gap-2">
                <span class="text-[#2fd17a] font-bold">7.</span>
                <span>Kita hendaklah <b>sentiasa memelihara solat</b> untuk melahirkan individu yang berdisiplin.</span>
              </li>
            </ul>
          </div>
        `
      }
    ]
  },
  {
    id: "t5-p5",
    number: 5,
    field: "al-quran",
    fieldLabel: "Bidang Al-Quran",
    title: "Pelajaran 5: Memahami Keutamaan dalam Tindakan (Surah at-Taubah: 19–20)",
    summary: "Konsep Fiqh al-Awwaliyyat (keutamaan tindakan), prinsip asas, sebab turun ayat, bidang pelaksanaan, kepentingan dan pengajaran ayat.",
    subtopics: [
      {
        id: "t5-p5-u1",
        badge: "UNIT 1",
        title: "Unit 1: Maksud & Prinsip Fiqh Al-Awwaliyyat (Fiqh Keutamaan)",
        contentHtml: `
          <div class="space-y-4">
            <div class="p-4 bg-[#1f2328] border-2 border-[#ffd447]">
              <h4 class="text-sm font-bold text-[#ffd447] uppercase tracking-wider mb-1">Maksud Fiqh Al-Awwaliyyat</h4>
              <p class="text-base text-white font-medium">
                <b>Mengutamakan perkara yang sepatutnya didahulukan berdasarkan prinsip syarak.</b>
              </p>
            </div>

            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <h4 class="text-sm font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-2">
                <span class="badge-tag bg-emerald-600 text-white font-bold px-2 py-0.5 text-xs">PRINSIP</span>
                5 Prinsip Asas Fiqh Al-Awwaliyyat
              </h4>
              <div class="grid sm:grid-cols-2 gap-3">
                <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-2.5">
                  <span class="text-[#ffd447] font-bold text-sm">1.</span>
                  <span class="text-sm text-slate-200">Bersumberkan <b>dalil syarak</b>.</span>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-2.5">
                  <span class="text-[#ffd447] font-bold text-sm">2.</span>
                  <span class="text-sm text-slate-200">Mengutamakan perkara yang <b>diutamakan oleh syarak</b>.</span>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-2.5">
                  <span class="text-[#ffd447] font-bold text-sm">3.</span>
                  <span class="text-sm text-slate-200">Mengambil kira <b>keperluan semasa dan setempat</b>.</span>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-2.5">
                  <span class="text-[#ffd447] font-bold text-sm">4.</span>
                  <span class="text-sm text-slate-200">Mengutamakan keperluan atau <b>manfaat bersama</b> berbanding manfaat peribadi.</span>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600 sm:col-span-2 flex items-start gap-2.5">
                  <span class="text-[#ffd447] font-bold text-sm">5.</span>
                  <span class="text-sm text-slate-200">Mengambil kira <b>tahap keupayaan individu</b>.</span>
                </div>
              </div>
            </div>
          </div>
        `
      },
      {
        id: "t5-p5-u2",
        badge: "UNIT 2",
        title: "Unit 2: Sebab Turun Ayat (Surah at-Taubah: 19–20)",
        contentHtml: `
          <div class="space-y-4">
            <!-- Teks Ayat Quran & Terjemahan -->
            <div class="p-4 bg-[#1f2328] border-2 border-stone-600 space-y-3">
              <span class="badge-tag bg-amber-500 text-stone-900 font-bold px-2 py-0.5 text-xs">SURAH AT-TAUBAH: 19–20</span>
              <p class="font-arabic text-xl md:text-2xl text-amber-200 leading-loose text-right" dir="rtl">
                ۞ أَجَعَلْتُمْ سِقَايَةَ ٱلْحَآجِّ وَعِمَارَةَ ٱلْمَسْجِدِ ٱلْحَرَامِ كَمَنْ ءَامَنَ بِٱللَّهِ وَٱلْيَوْمِ ٱلْـَٔاخِرِ وَجَـٰهَدَ فِى سَبِيلِ ٱللَّهِ ۚ لَا يَسْتَوُۥنَ عِندَ ٱللَّهِ ۗ وَٱللَّهُ لَا يَهْدِى ٱلْقَوْمَ ٱلظَّـٰلِمِينَ ﴿١٩﴾ ٱلَّذِينَ ءَامَنُوا۟ وَهَاجَرُوا۟ وَجَـٰهَدُوا۟ فِى سَبِيلِ ٱللَّهِ بِأَمْوَٰلِهِمْ وَأَنفُسِهِمْ أَعْظَمُ دَرَجَةً عِندَ ٱللَّهِ ۚ وَأُو۟لَـٰٓئِكَ هُمُ ٱلْفَآئِزُونَ ﴿٢٠﴾
              </p>
              <div class="p-3 bg-[#2d3036] border border-stone-600 text-xs text-slate-300 leading-relaxed space-y-1">
                <p><b>Maksud Ayat 19:</b> Adakah kamu menyifatkan perbuatan memberi minum kepada orang-orang yang mengerjakan haji dan memakmurkan Masjid al-Haram itu sama seperti orang yang beriman kepada Allah dan hari akhirat serta berjihad pada jalan Allah? Mereka tidak sama di sisi Allah. Dan Allah tidak memberi petunjuk kepada kaum yang zalim.</p>
                <p><b>Maksud Ayat 20:</b> Orang-orang yang beriman dan berhijrah serta berjihad pada jalan Allah dengan harta benda dan jiwa mereka adalah lebih besar darjatnya di sisi Allah; dan mereka itulah orang-orang yang berjaya.</p>
              </div>
            </div>

            <!-- Asbabun Nuzul -->
            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <h4 class="text-sm font-bold text-[#ffd447] uppercase tracking-wider mb-2">Riwayat Sebab Turun Ayat</h4>
              <p class="text-sm text-slate-300 leading-relaxed">
                Menurut <b>Nu'man bin Bashir RA</b>, beberapa orang sahabat telah berbincang tentang amalan yang mereka utamakan selepas Pembukaan Kota Mekah:
              </p>
              <div class="mt-3 p-3 bg-[#2d3036] border-l-4 border-[#ffd447] text-sm text-slate-200 space-y-2">
                <p>• Ada sahabat yang mengutamakan <b>memberi minum kepada orang yang menunaikan haji</b>.</p>
                <p>• Ada sahabat yang mengutamakan <b>memakmurkan Masjid al-Haram</b>.</p>
                <p>• Ada sahabat yang mengutamakan <b>berjihad di jalan Allah SWT</b>.</p>
              </div>
              <p class="text-sm text-slate-300 mt-3 leading-relaxed">
                Percakapan mereka ditegur oleh <b>Saidina Umar bin al-Khattab RA</b>. Beliau kemudian mengadu hal ini kepada Rasulullah SAW, lalu turunlah ayat 19–20 Surah At-Taubah untuk menjelaskan <b>keutamaan beriman dan berjihad</b> berbanding sekadar memberi minum jemaah haji atau memakmurkan masjid tanpa asas keimanan yang kukuh.
              </p>
            </div>
          </div>
        `
      },
      {
        id: "t5-p5-u3",
        badge: "UNIT 3",
        title: "Unit 3: Bidang Pelaksanaan Fiqh Al-Awwaliyyat",
        contentHtml: `
          <div class="space-y-4">
            <p class="text-sm text-slate-300">
              Pelaksanaan Fiqh al-Awwaliyyat merangkumi 3 bidang utama:
            </p>

            <!-- 3.1 Ilmu dan Pemikiran -->
            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2 mb-2">
                <span class="badge-tag bg-blue-600 text-white font-bold px-2 py-0.5 text-xs">UNIT 3.1</span>
                <h4 class="text-base font-bold text-white">Bidang Ilmu dan Pemikiran</h4>
              </div>
              <div class="p-3 bg-[#2d3036] border border-stone-600 mb-3">
                <strong class="text-xs text-[#ffd447] uppercase block mb-1">Prinsip Am:</strong>
                <p class="text-sm text-slate-200">
                  Mengutamakan usaha menuntut ilmu dan kefahaman berbanding dengan amalan.
                </p>
              </div>
              <div class="p-3 bg-[#2d3036] border-l-4 border-blue-500">
                <strong class="text-xs text-blue-300 uppercase block mb-1">Aplikasi / Contoh:</strong>
                <p class="text-sm text-slate-200">
                  Mengutamakan ilmu <b>Fardu Ain</b> berbanding ilmu <b>Fardu Kifayah</b>.
                </p>
              </div>
            </div>

            <!-- 3.2 Amalan -->
            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2 mb-2">
                <span class="badge-tag bg-emerald-600 text-white font-bold px-2 py-0.5 text-xs">UNIT 3.2</span>
                <h4 class="text-base font-bold text-white">Bidang Amalan</h4>
              </div>
              <div class="p-3 bg-[#2d3036] border border-stone-600 mb-3">
                <strong class="text-xs text-[#ffd447] uppercase block mb-1">Prinsip Am:</strong>
                <p class="text-sm text-slate-200">
                  Mengutamakan amalan yang banyak manfaat berbanding dengan amalan yang kurang bermanfaat.
                </p>
              </div>
              <div class="p-3 bg-[#2d3036] border-l-4 border-emerald-500 space-y-2">
                <strong class="text-xs text-emerald-300 uppercase block mb-1">Aplikasi / Contoh:</strong>
                <p class="text-sm text-slate-200">
                  1. Mengutamakan amalan yang memberi manfaat kepada masyarakat berbanding amalan yang berkesan kepada individu sahaja <i>(contoh: bersedekah atau aktiviti kemasyarakatan berbanding amalan sunat peribadi)</i>.
                </p>
                <p class="text-sm text-slate-200">
                  2. Mengutamakan aktiviti kemasyarakatan berbanding ibadah sunat peribadi.
                </p>
              </div>
            </div>

            <!-- 3.3 Tuntutan Syarak -->
            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2 mb-2">
                <span class="badge-tag bg-amber-600 text-white font-bold px-2 py-0.5 text-xs">UNIT 3.3</span>
                <h4 class="text-base font-bold text-white">Bidang Tuntutan Syarak</h4>
              </div>
              <div class="p-3 bg-[#2d3036] border border-stone-600 mb-3">
                <strong class="text-xs text-[#ffd447] uppercase block mb-1">Prinsip Am:</strong>
                <p class="text-sm text-slate-200">
                  Mengutamakan perkara pokok (<i>Usul</i>) berbanding perkara cabang (<i>Furu'</i>).
                </p>
              </div>
              <div class="p-3 bg-[#2d3036] border-l-4 border-amber-500 space-y-2">
                <strong class="text-xs text-amber-300 uppercase block mb-1">Aplikasi / Contoh:</strong>
                <p class="text-sm text-slate-200">
                  1. <b>Fardu Ain vs Fardu Kifayah:</b> Mengutamakan amalan Fardu Ain berbanding Fardu Kifayah <i>(contoh: menunaikan zakat yang wajib sebelum bersedekah)</i>.
                </p>
                <p class="text-sm text-slate-200">
                  2. <b>Fardu vs Sunat:</b> Mengutamakan amalan fardu berbanding amalan sunat <i>(contoh: membantu ibu bapa berbanding beriktikaf)</i>.
                </p>
                <p class="text-sm text-slate-200">
                  3. <b>Akidah vs Syariat Cabang:</b> Menguasai asas akidah Islam terlebih dahulu berbanding mempelajari isu-isu cabang fikah.
                </p>
              </div>
            </div>
          </div>
        `
      },
      {
        id: "t5-p5-u4",
        badge: "UNIT 4",
        title: "Unit 4: Kepentingan Fiqh Al-Awwaliyyat",
        contentHtml: `
          <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
            <h4 class="text-sm font-bold text-white uppercase tracking-wider mb-3">
              6 Kepentingan Fiqh Al-Awwaliyyat Terhadap Individu & Masyarakat
            </h4>
            <div class="grid sm:grid-cols-2 gap-3">
              <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-2.5">
                <span class="text-[#ffd447] font-bold text-sm">1.</span>
                <span class="text-sm text-slate-200">Memastikan <b>tindakan manusia terkawal dan sistematik</b>.</span>
              </div>
              <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-2.5">
                <span class="text-[#ffd447] font-bold text-sm">2.</span>
                <span class="text-sm text-slate-200">Membuahkan <b>hasil kerja yang berkualiti dan efektif</b>.</span>
              </div>
              <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-2.5">
                <span class="text-[#ffd447] font-bold text-sm">3.</span>
                <span class="text-sm text-slate-200">Mengamalkan semua tuntutan Islam mengikut <b>susunan yang tepat</b>.</span>
              </div>
              <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-2.5">
                <span class="text-[#ffd447] font-bold text-sm">4.</span>
                <span class="text-sm text-slate-200">Mewujudkan <b>kesejahteraan sosial</b> dalam melestarikan pengurusan kehidupan.</span>
              </div>
              <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-2.5">
                <span class="text-[#ffd447] font-bold text-sm">5.</span>
                <span class="text-sm text-slate-200">Membimbing kehidupan masyarakat dalam <b>pelaksanaan tuntutan syariat</b>.</span>
              </div>
              <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-2.5">
                <span class="text-[#ffd447] font-bold text-sm">6.</span>
                <span class="text-sm text-slate-200">Mewujudkan masyarakat yang berjaya <b>menguruskan sistem kehidupan yang cekap</b>.</span>
              </div>
            </div>
          </div>
        `
      },
      {
        id: "t5-p5-u5",
        badge: "UNIT 5",
        title: "Unit 5: Pengajaran Ayat (Surah at-Taubah: 19–20)",
        contentHtml: `
          <div class="p-4 bg-[#1f2328] border-2 border-[#2fd17a]">
            <h4 class="text-base font-bold text-[#2fd17a] mb-3">
              Sebagai umat Islam, kita hendaklah:
            </h4>
            <ul class="space-y-3 text-sm text-slate-200">
              <li class="flex items-start gap-2.5 p-2 bg-[#2d3036] border border-stone-600">
                <span class="text-[#2fd17a] font-bold text-base">1.</span>
                <span>Sentiasa <b>meningkatkan keimanan</b> kepada Allah SWT dan hari akhirat kerana keimanan ialah kunci penerimaan segala ibadah.</span>
              </li>
              <li class="flex items-start gap-2.5 p-2 bg-[#2d3036] border border-stone-600">
                <span class="text-[#2fd17a] font-bold text-base">2.</span>
                <span>Sentiasa <b>berazam untuk berjihad</b> dengan tenaga dan harta supaya mendapat ganjaran yang besar di sisi Allah SWT.</span>
              </li>
              <li class="flex items-start gap-2.5 p-2 bg-[#2d3036] border border-stone-600">
                <span class="text-[#2fd17a] font-bold text-base">3.</span>
                <span>Sentiasa <b>berhijrah kepada yang lebih baik</b> supaya menjadi insan yang produktif.</span>
              </li>
              <li class="flex items-start gap-2.5 p-2 bg-[#2d3036] border border-stone-600">
                <span class="text-[#2fd17a] font-bold text-base">4.</span>
                <span>Sentiasa <b>berlumba-lumba melakukan kebaikan</b> kerana kebaikan itu akan diberi ganjaran pada hari akhirat.</span>
              </li>
            </ul>
          </div>
        `
      }
    ]
  },
  {
    id: "t5-p6",
    number: 6,
    field: "al-quran",
    fieldLabel: "Bidang Al-Quran (Kefahaman)",
    title: "Pelajaran 6: Kepelbagaian Bangsa dalam Islam (Surah Al-Hujurat: 13)",
    summary: "Hikmah kepelbagaian bangsa dan kabilah untuk saling mengenali (li-ta'arafu), keutamaan takwa, serta penolakan diskriminasi perkauman.",
    subtopics: [
      {
        id: "t5-p6-u1",
        badge: "UNIT 1",
        title: "Unit 1: Teks & Terjemahan Ayat (Surah Al-Hujurat: 13)",
        contentHtml: `
          <div class="space-y-4">
            <div class="p-4 bg-[#1f2328] border-2 border-stone-600 space-y-3">
              <span class="badge-tag bg-amber-500 text-stone-900 font-bold px-2 py-0.5 text-xs">SURAH AL-HUJURAT: 13</span>
              <p class="font-arabic text-xl md:text-2xl text-amber-200 leading-loose text-right" dir="rtl">
                يَـٰٓأَيُّهَا ٱلنَّاسُ إِنَّا خَلَقْنَـٰكُم مِّن ذَكَرٍۢ وَأُنثَىٰ وَجَعَلْنَـٰكُمْ شُعُوبًۭا وَقَبَآئِلَ لِتَعَارَفُوٓا۟ ۚ إِنَّ أَكْرَمَكُمْ عِندَ ٱللَّهِ أَتْقَىٰكُمْ ۚ إِنَّ ٱللَّهَ عَلِيمٌ خَبِيرٌۭ ﴿١٣﴾
              </p>
              <div class="p-3 bg-[#2d3036] border border-stone-600 text-sm text-slate-200 leading-relaxed">
                <blockquote class="italic border-l-4 border-[#ffd447] pl-3 py-1">
                  "Wahai manusia! Sesungguhnya Kami telah menciptakan kamu daripada lelaki dan perempuan, dan Kami telah menjadikan kamu pelbagai bangsa dan bersuku-puak supaya kamu saling kenal-mengenali. Sesungguhnya orang yang paling mulia di sisi Allah dalam kalangan kamu ialah orang yang paling bertakwa. Sesungguhnya Allah Maha Mengetahui, lagi Maha Mendalam Pengetahuan-Nya."
                </blockquote>
              </div>
            </div>
          </div>
        `
      },
      {
        id: "t5-p6-u2",
        badge: "UNIT 2",
        title: "Unit 2: Sebab Turun Ayat (Asbabun Nuzul)",
        contentHtml: `
          <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d] space-y-3">
            <h4 class="text-sm font-bold text-[#ffd447] uppercase tracking-wider">Peristiwa Semasa Pembukaan Kota Mekah (Fath Makkah)</h4>
            <div class="space-y-2.5 text-sm text-slate-200 leading-relaxed">
              <p class="flex items-start gap-2">
                <span class="text-[#ffd447] font-bold">•</span>
                <span>Menurut <b>Ibn Abbas RA</b>, Rasulullah SAW telah meminta <b>Saidina Bilal bin Rabah RA</b> melaungkan azan semasa Pembukaan Kota Mekah.</span>
              </p>
              <p class="flex items-start gap-2">
                <span class="text-[#ffd447] font-bold">•</span>
                <span>Terdapat sebilangan sahabat yang memandang rendah kepada Saidina Bilal RA disebabkan latar belakang beliau (berkulit hitam dan bekas hamba).</span>
              </p>
              <p class="flex items-start gap-2">
                <span class="text-[#ffd447] font-bold">•</span>
                <span>Malaikat Jibril AS memberitahu Rasulullah SAW tentang perbuatan dan perbualan para sahabat tersebut.</span>
              </p>
              <p class="flex items-start gap-2">
                <span class="text-[#ffd447] font-bold">•</span>
                <span>Rasulullah SAW kemudian memanggil mereka dan bertanyakan tentang tindakan mereka, lalu turunlah ayat 13 Surah Al-Hujurat ini bagi menegaskan bahawa kemuliaan manusia terletak pada ketakwaan, bukannya rupa paras atau keturunan.</span>
              </p>
            </div>
          </div>
        `
      },
      {
        id: "t5-p6-u3",
        badge: "UNIT 3",
        title: "Unit 3: Kandungan & Tuntutan Ayat",
        contentHtml: `
          <div class="space-y-4">
            <!-- 3.1 Tuntutan Saling Mengenali -->
            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2 mb-3">
                <span class="badge-tag bg-blue-600 text-white font-bold px-2 py-0.5 text-xs">UNIT 3.1</span>
                <h4 class="text-base font-bold text-white">Tuntutan Saling Mengenali dalam Kalangan Pelbagai Bangsa</h4>
              </div>
              <div class="grid sm:grid-cols-2 gap-3">
                <div class="p-3 bg-[#2d3036] border border-stone-600 space-y-1">
                  <strong class="text-sm text-[#ffd447] block">1. Menjalin Perpaduan</strong>
                  <p class="text-xs text-slate-200">Mewujudkan perpaduan dan hubungan yang harmoni dalam masyarakat.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600 space-y-1">
                  <strong class="text-sm text-[#ffd447] block">2. Mengiktiraf Kemuliaan Manusia</strong>
                  <p class="text-xs text-slate-200">Mengiktiraf kemuliaan dan harga diri manusia tanpa mengira rupa paras dan etnik.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600 space-y-1">
                  <strong class="text-sm text-[#ffd447] block">3. Hubungan dengan Bukan Muslim</strong>
                  <p class="text-xs text-slate-200">Menjalin hubungan yang baik dengan orang bukan Islam selagi mereka tidak memusuhi Islam.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600 space-y-1">
                  <strong class="text-sm text-[#ffd447] block">4. Saling Melengkapi</strong>
                  <p class="text-xs text-slate-200">Mengukuhkan interaksi dan kerjasama yang saling melengkapi antara satu sama lain.</p>
                </div>
              </div>
            </div>

            <!-- 3.2 Keutamaan Takwa -->
            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2 mb-3">
                <span class="badge-tag bg-amber-600 text-white font-bold px-2 py-0.5 text-xs">UNIT 3.2</span>
                <h4 class="text-base font-bold text-white">Keutamaan Takwa Sebagai Kayu Ukur Kemuliaan</h4>
              </div>
              <div class="grid sm:grid-cols-2 gap-3">
                <div class="p-3 bg-[#2d3036] border border-stone-600 space-y-1">
                  <strong class="text-sm text-[#2fd17a] block">1. Penyamaan Taraf Manusia</strong>
                  <p class="text-xs text-slate-200">Semua manusia adalah sama di sisi Allah SWT tanpa mengira bangsa atau keturunan.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600 space-y-1">
                  <strong class="text-sm text-[#2fd17a] block">2. Ukuran Kemuliaan Sebenar</strong>
                  <p class="text-xs text-slate-200">Allah SWT tidak melihat jantina atau bangsa, sebaliknya menilai hati dan amalan hamba-Nya.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600 space-y-1">
                  <strong class="text-sm text-[#2fd17a] block">3. Meyakini Kekuasaan Allah</strong>
                  <p class="text-xs text-slate-200">Meyakini kekuasaan Allah SWT melalui kepelbagaian makhluk ciptaan-Nya sebagai asas keimanan.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600 space-y-1">
                  <strong class="text-sm text-[#2fd17a] block">4. Menunaikan Hak Sesama Manusia</strong>
                  <p class="text-xs text-slate-200">Menunaikan hak sesama manusia walaupun berbeza kaum dan budaya kerana ia merupakan perintah Allah SWT.</p>
                </div>
              </div>
            </div>
          </div>
        `
      },
      {
        id: "t5-p6-u4",
        badge: "UNIT 4",
        title: "Unit 4: Pengajaran Ayat (Surah Al-Hujurat: 13)",
        contentHtml: `
          <div class="p-4 bg-[#1f2328] border-2 border-[#2fd17a]">
            <h4 class="text-base font-bold text-[#2fd17a] mb-3">
              Sebagai umat Islam, kita hendaklah:
            </h4>
            <ul class="space-y-3 text-sm text-slate-200">
              <li class="flex items-start gap-2.5 p-3 bg-[#2d3036] border border-stone-600">
                <span class="text-[#2fd17a] font-bold text-base">1.</span>
                <span><b>Saling bekerjasama</b> untuk membina kehidupan yang harmoni dan sejahtera.</span>
              </li>
              <li class="flex items-start gap-2.5 p-3 bg-[#2d3036] border border-stone-600">
                <span class="text-[#2fd17a] font-bold text-base">2.</span>
                <span><b>Menghormati kepelbagaian budaya</b> supaya wujud persefahaman dan saling bertoleransi dalam kalangan masyarakat.</span>
              </li>
              <li class="flex items-start gap-2.5 p-3 bg-[#2d3036] border border-stone-600">
                <span class="text-[#2fd17a] font-bold text-base">3.</span>
                <span><b>Berusaha membaiki akhlak</b> supaya menjadi insan yang bertakwa dan mulia di sisi Allah SWT.</span>
              </li>
            </ul>
          </div>
        `
      }
    ]
  },

  // ==========================================
  // 2. BIDANG HADIS
  // ==========================================
  {
    id: "t5-p7",
    number: 7,
    field: "hadis",
    fieldLabel: "Bidang Hadis",
    title: "Pelajaran 7: Setiap Orang Ialah Pemimpin",
    summary: "Hadis tanggungjawab kepimpinan diri, keluarga, majikan, pekerja, dan pemerintah.",
    directContentHtml: `
      <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d] mb-4">
        <span class="field-label text-xs">PANDUAN TAJUK TINGKATAN 5</span>
        <h4 class="text-white font-bold text-base mt-2">Pelajaran 7: Setiap Orang Ialah Pemimpin («كُلُّكُمْ رَاعٍ»)</h4>
        <p class="text-sm text-slate-300 mt-1">Hadis riwayat al-Bukhari & Muslim mengenai amanah kepimpinan pemimpin negara, suami terhadap keluarga, isteri terhadap rumah tangga, dan pekerja terhadap harta majikan.</p>
      </div>
    `
  },
  {
    id: "t5-p8",
    number: 8,
    field: "hadis",
    fieldLabel: "Bidang Hadis",
    title: "Pelajaran 8: Tujuh Golongan yang Mendapat Naungan Allah SWT",
    summary: "Hadis naungan perlindungan di Padang Mahsyar bagi 7 kategori insan bertakwa riwayat Abu Hurairah RA.",
    subtopics: [
      {
        id: "t5-p8-u1",
        badge: "UNIT 1",
        title: "Unit 1: Pengenalan & Maksud Naungan Allah SWT",
        contentHtml: `
          <div class="space-y-4">
            <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d]">
              <div class="flex items-center gap-2 mb-2">
                <span class="badge-tag bg-amber-600 text-white font-bold px-2 py-0.5 text-xs">PERAWI HADIS</span>
                <h4 class="text-sm font-bold text-white uppercase tracking-wider">Diriwayatkan daripada Abu Hurairah RA (Muttafaq 'Alaih)</h4>
              </div>
              <p class="text-sm text-slate-300 leading-relaxed">
                Hadis ini merupakan antara hadis yang sangat agung dalam menggambarkan keadilan dan kasih sayang Allah SWT kepada hamba-hamba-Nya yang istiqamah dalam ketaatan.
              </p>
            </div>

            <div class="p-4 bg-[#2d3036] border-2 border-[#ffd447]">
              <h4 class="text-sm font-bold text-[#ffd447] mb-2 flex items-center gap-2">
                <span>🛡️</span>
                <span>Maksud Naungan Allah SWT di Padang Mahsyar</span>
              </h4>
              <p class="text-sm text-slate-200 leading-relaxed">
                Mengikut penjelasan kitab <b>Fath al-Bari</b> karangan al-Hafiz Ibn Hajar al-'Asqalani, naungan Allah SWT bermaksud:
              </p>
              <div class="p-3 bg-[#1f2328] border-l-4 border-[#2fd17a] mt-2 text-white font-medium text-sm">
                "Mendapat perlindungan daripada kepanasan cahaya matahari di Padang Mahsyar pada hari yang tiada sebarang naungan melainkan naungan-Nya."
              </div>
            </div>
          </div>
        `
      },
      {
        id: "t5-p8-u2",
        badge: "UNIT 2",
        title: "Unit 2: Terjemahan & Potongan Hadis (Jadual Hafazan)",
        contentHtml: `
          <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d] space-y-3">
            <div class="flex items-center justify-between flex-wrap gap-2">
              <h4 class="text-sm font-bold text-[#ffd447] uppercase tracking-wider">
                Jadual 7 Golongan yang Mendapat Naungan Allah SWT
              </h4>
              <span class="text-xs bg-[#2b1a0c] text-amber-200 px-2 py-0.5 border border-amber-700">Fokus Hafazan SPM</span>
            </div>
            <p class="text-xs text-slate-300">
              Berikut ialah teks potongan hadis mengikut tertib berserta terjemahannya untuk hafazan pelajar:
            </p>

            <div class="overflow-x-auto border-2 border-[#5e646d]">
              <table class="w-full text-left text-sm text-slate-200 border-collapse">
                <thead class="bg-[#2d3036] text-amber-300 text-xs font-bold uppercase border-b-2 border-[#5e646d]">
                  <tr>
                    <th class="p-3 w-12 text-center border-r border-[#5e646d]">Bil.</th>
                    <th class="p-3 border-r border-[#5e646d]">Potongan Hadis (Teks Arab)</th>
                    <th class="p-3">Maksud / Terjemahan</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#3d424b] text-xs sm:text-sm">
                  <tr class="hover:bg-[#25282f] transition-colors">
                    <td class="p-3 font-bold text-center border-r border-[#5e646d] text-[#ffd447]">1</td>
                    <td class="p-3 font-arabic text-lg text-amber-200 border-r border-[#5e646d] text-right" dir="rtl">
                      الإِمَامُ الْعَادِلُ
                    </td>
                    <td class="p-3 font-medium text-white">
                      Pemimpin yang adil.
                    </td>
                  </tr>
                  <tr class="hover:bg-[#25282f] transition-colors bg-[#1c1f24]">
                    <td class="p-3 font-bold text-center border-r border-[#5e646d] text-[#ffd447]">2</td>
                    <td class="p-3 font-arabic text-lg text-amber-200 border-r border-[#5e646d] text-right" dir="rtl">
                      وَشَابٌّ نَشَأَ فِي عِبَادَةِ رَبِّهِ
                    </td>
                    <td class="p-3 font-medium text-white">
                      Pemuda yang hidupnya taat beribadah kepada Allah SWT.
                    </td>
                  </tr>
                  <tr class="hover:bg-[#25282f] transition-colors">
                    <td class="p-3 font-bold text-center border-r border-[#5e646d] text-[#ffd447]">3</td>
                    <td class="p-3 font-arabic text-lg text-amber-200 border-r border-[#5e646d] text-right" dir="rtl">
                      وَرَجُلٌ قَلْبُهُ مُعَلَّقٌ فِي الْمَسَاجِدِ
                    </td>
                    <td class="p-3 font-medium text-white">
                      Seseorang yang hatinya sentiasa mencintai masjid.
                    </td>
                  </tr>
                  <tr class="hover:bg-[#25282f] transition-colors bg-[#1c1f24]">
                    <td class="p-3 font-bold text-center border-r border-[#5e646d] text-[#ffd447]">4</td>
                    <td class="p-3 font-arabic text-lg text-amber-200 border-r border-[#5e646d] text-right" dir="rtl">
                      وَرَجُلاَنِ تَحَابَّا فِي اللَّهِ اجْتَمَعَا عَلَيْهِ وَتَفَرَّقَا عَلَيْهِ
                    </td>
                    <td class="p-3 font-medium text-white">
                      Dua orang yang saling mengasihi kerana Allah SWT, bertemu dan berpisah kerana-Nya.
                    </td>
                  </tr>
                  <tr class="hover:bg-[#25282f] transition-colors">
                    <td class="p-3 font-bold text-center border-r border-[#5e646d] text-[#ffd447]">5</td>
                    <td class="p-3 font-arabic text-lg text-amber-200 border-r border-[#5e646d] text-right" dir="rtl">
                      وَرَجُلٌ طَلَبَتْهُ امْرَأَةٌ ذَاتُ مَنْصِبٍ وَجَمَالٍ فَقَالَ إِنِّي أَخَافُ اللَّهَ
                    </td>
                    <td class="p-3 font-medium text-white">
                      Seseorang yang membenci maksiat kerana takut kepada Allah SWT (diajak melakukan maksiat oleh wanita berpangkat dan cantik lalu menolaknya).
                    </td>
                  </tr>
                  <tr class="hover:bg-[#25282f] transition-colors bg-[#1c1f24]">
                    <td class="p-3 font-bold text-center border-r border-[#5e646d] text-[#ffd447]">6</td>
                    <td class="p-3 font-arabic text-lg text-amber-200 border-r border-[#5e646d] text-right" dir="rtl">
                      وَرَجُلٌ تَصَدَّقَ أَخْفَى حَتَّى لاَ تَعْلَمَ شِمَالُهُ مَا تُنْفِقُ يَمِينُهُ
                    </td>
                    <td class="p-3 font-medium text-white">
                      Seseorang yang bersedekah secara sembunyi (sehingga tangan kirinya tidak mengetahui apa yang diinfakkan oleh tangan kanannya).
                    </td>
                  </tr>
                  <tr class="hover:bg-[#25282f] transition-colors">
                    <td class="p-3 font-bold text-center border-r border-[#5e646d] text-[#ffd447]">7</td>
                    <td class="p-3 font-arabic text-lg text-amber-200 border-r border-[#5e646d] text-right" dir="rtl">
                      وَرَجُلٌ ذَكَرَ اللَّهَ خَالِيًا فَفَاضَتْ عَيْنَاهُ
                    </td>
                    <td class="p-3 font-medium text-white">
                      Seseorang yang mengingati Allah SWT secara bersendirian sehingga menitiskan air mata.
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        `
      },
      {
        id: "t5-p8-u3",
        badge: "UNIT 3",
        title: "Unit 3: Huraian Maksud & Contoh Amalan 7 Golongan",
        contentHtml: `
          <div class="space-y-4">
            <!-- Golongan 1 -->
            <div class="p-4 bg-[#1f2328] border-2 border-[#ffd447]">
              <div class="flex items-center gap-2 mb-2">
                <span class="badge-tag bg-[#ffd447] text-black font-extrabold px-2 py-0.5 text-xs">GOLONGAN 1</span>
                <h4 class="text-base font-bold text-white">Pemimpin yang Adil (الإِمَامُ الْعَادِلُ)</h4>
              </div>
              <div class="grid sm:grid-cols-2 gap-3 text-sm">
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#ffd447] uppercase block mb-1">Maksud:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Pemimpin yang menjalankan tanggungjawab terhadap orang di bawah pimpinannya berpandukan al-Quran dan Hadis.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#2fd17a] uppercase block mb-1">Contoh Amalan:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Memastikan keperluan asas rakyat dipenuhi dan mencegah kemungkaran daripada berleluasa.</p>
                </div>
              </div>
            </div>

            <!-- Golongan 2 -->
            <div class="p-4 bg-[#1f2328] border-2 border-[#2fd17a]">
              <div class="flex items-center gap-2 mb-2">
                <span class="badge-tag bg-[#2fd17a] text-black font-extrabold px-2 py-0.5 text-xs">GOLONGAN 2</span>
                <h4 class="text-base font-bold text-white">Pemuda yang Hidupnya Taat Beribadah kepada Allah SWT</h4>
              </div>
              <div class="grid sm:grid-cols-2 gap-3 text-sm">
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#ffd447] uppercase block mb-1">Maksud:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Pemuda yang memenuhi masa usianya dengan melakukan ibadah kepada Allah SWT, sama ada ibadah wajib atau sunat.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#2fd17a] uppercase block mb-1">Contoh Amalan:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Melaksanakan tuntutan solat fardu lima waktu dan puasa dengan sempurna, melazimi qiamullail, membaca al-Quran, serta berzikir.</p>
                </div>
              </div>
            </div>

            <!-- Golongan 3 -->
            <div class="p-4 bg-[#1f2328] border-2 border-cyan-500">
              <div class="flex items-center gap-2 mb-2">
                <span class="badge-tag bg-cyan-500 text-black font-extrabold px-2 py-0.5 text-xs">GOLONGAN 3</span>
                <h4 class="text-base font-bold text-white">Seseorang yang Hatinya Sentiasa Mencintai Masjid</h4>
              </div>
              <div class="grid sm:grid-cols-2 gap-3 text-sm">
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#ffd447] uppercase block mb-1">Maksud:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Seseorang yang hatinya sentiasa berasa seronok memakmurkan masjid dengan aktiviti ibadah dan kebajikan.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#2fd17a] uppercase block mb-1">Contoh Amalan:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Menunaikan solat fardu secara berjemaah serta menyertai aktiviti di masjid seperti majlis ilmu dan gotong-royong.</p>
                </div>
              </div>
            </div>

            <!-- Golongan 4 -->
            <div class="p-4 bg-[#1f2328] border-2 border-purple-500">
              <div class="flex items-center gap-2 mb-2">
                <span class="badge-tag bg-purple-500 text-white font-extrabold px-2 py-0.5 text-xs">GOLONGAN 4</span>
                <h4 class="text-base font-bold text-white">Dua Orang yang Saling Mengasihi Kerana Allah SWT</h4>
              </div>
              <div class="grid sm:grid-cols-2 gap-3 text-sm">
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#ffd447] uppercase block mb-1">Maksud:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Dua orang yang bersahabat berasaskan keimanan dan ketakwaan kepada Allah SWT — bertemu dan berpisah semata-mata kerana Allah SWT.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#2fd17a] uppercase block mb-1">Contoh Amalan:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Persaudaraan antara kaum Muhajirin dan Ansar serta kesetiaan Saidina Abu Bakar al-Siddiq RA mendampingi Rasulullah SAW.</p>
                </div>
              </div>
            </div>

            <!-- Golongan 5 -->
            <div class="p-4 bg-[#1f2328] border-2 border-rose-500">
              <div class="flex items-center gap-2 mb-2">
                <span class="badge-tag bg-rose-500 text-white font-extrabold px-2 py-0.5 text-xs">GOLONGAN 5</span>
                <h4 class="text-base font-bold text-white">Seseorang yang Membenci Maksiat Kerana Takut kepada Allah SWT</h4>
              </div>
              <div class="grid sm:grid-cols-2 gap-3 text-sm">
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#ffd447] uppercase block mb-1">Maksud:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Seseorang yang membenci dan menjauhi semua perbuatan yang melanggar suruhan Allah SWT atau meninggalkan larangan-Nya kerana takutkan azab Allah SWT.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#2fd17a] uppercase block mb-1">Contoh Amalan:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Menjauhi perbuatan mencuri, berzina, dan menghindari pergaulan bebas tanpa batasan syarak.</p>
                </div>
              </div>
            </div>

            <!-- Golongan 6 -->
            <div class="p-4 bg-[#1f2328] border-2 border-emerald-500">
              <div class="flex items-center gap-2 mb-2">
                <span class="badge-tag bg-emerald-500 text-black font-extrabold px-2 py-0.5 text-xs">GOLONGAN 6</span>
                <h4 class="text-base font-bold text-white">Seseorang yang Bersedekah Secara Sembunyi</h4>
              </div>
              <div class="grid sm:grid-cols-2 gap-3 text-sm">
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#ffd447] uppercase block mb-1">Maksud:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Pemberian yang bertujuan mendekatkan diri kepada Allah SWT semata-mata tanpa mengharapkan pujian manusia.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#2fd17a] uppercase block mb-1">Contoh Amalan:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Memberikan sumbangan kewangan secara dalam talian (online banking) atau mewakafkan tanah untuk pembinaan masjid secara berdiam diri.</p>
                </div>
              </div>
            </div>

            <!-- Golongan 7 -->
            <div class="p-4 bg-[#1f2328] border-2 border-blue-400">
              <div class="flex items-center gap-2 mb-2">
                <span class="badge-tag bg-blue-400 text-black font-extrabold px-2 py-0.5 text-xs">GOLONGAN 7</span>
                <h4 class="text-base font-bold text-white">Seseorang yang Mengingati Allah SWT Secara Bersendirian Sehingga Menitiskan Air Mata</h4>
              </div>
              <div class="grid sm:grid-cols-2 gap-3 text-sm">
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#ffd447] uppercase block mb-1">Maksud:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Seseorang yang mengingati Allah SWT sama ada melalui hati atau lisan dengan ikhlas dan gerun kepada-Nya ketika berada bersendirian.</p>
                </div>
                <div class="p-3 bg-[#2d3036] border border-stone-600">
                  <span class="text-xs font-bold text-[#2fd17a] uppercase block mb-1">Contoh Amalan:</span>
                  <p class="text-slate-200 text-xs sm:text-sm">Beristighfar memohon keampunan daripada Allah SWT dengan penyesalan yang mendalam atas dosa-dosa lalu.</p>
                </div>
              </div>
            </div>
          </div>
        `
      },
      {
        id: "t5-p8-u4",
        badge: "UNIT 4",
        title: "Unit 4: Pengajaran Hadis (7 Pengajaran Utama)",
        contentHtml: `
          <div class="p-4 bg-[#1f2328] border-2 border-[#2fd17a]">
            <h4 class="text-base font-bold text-[#2fd17a] mb-3">
              Sebagai umat Islam, kita hendaklah:
            </h4>
            <div class="grid sm:grid-cols-2 gap-2.5 text-xs sm:text-sm text-slate-200">
              <div class="p-2.5 bg-[#2d3036] border border-stone-600 flex items-start gap-2">
                <span class="text-[#ffd447] font-bold">1.</span>
                <span><b>Berlaku adil</b> dalam setiap tindakan kerana sikap tersebut merupakan suruhan Allah SWT.</span>
              </div>
              <div class="p-2.5 bg-[#2d3036] border border-stone-600 flex items-start gap-2">
                <span class="text-[#ffd447] font-bold">2.</span>
                <span><b>Memanfaatkan usia muda</b> dengan mendekatkan diri kepada Allah SWT.</span>
              </div>
              <div class="p-2.5 bg-[#2d3036] border border-stone-600 flex items-start gap-2">
                <span class="text-[#ffd447] font-bold">3.</span>
                <span><b>Memakmurkan masjid</b> agar syiar Islam dapat ditegakkan.</span>
              </div>
              <div class="p-2.5 bg-[#2d3036] border border-stone-600 flex items-start gap-2">
                <span class="text-[#ffd447] font-bold">4.</span>
                <span><b>Saling mengasihi</b> sesama Muslim supaya masyarakat hidup aman dan damai.</span>
              </div>
              <div class="p-2.5 bg-[#2d3036] border border-stone-600 flex items-start gap-2">
                <span class="text-[#ffd447] font-bold">5.</span>
                <span><b>Menjauhi perbuatan maksiat</b> agar selamat daripada kemurkaan Allah SWT.</span>
              </div>
              <div class="p-2.5 bg-[#2d3036] border border-stone-600 flex items-start gap-2">
                <span class="text-[#ffd447] font-bold">6.</span>
                <span><b>Memperbanyakkan sedekah</b> kerana amalan tersebut dapat menyucikan harta dan jiwa.</span>
              </div>
              <div class="p-2.5 bg-[#2d3036] border border-stone-600 flex items-start gap-2 sm:col-span-2">
                <span class="text-[#ffd447] font-bold">7.</span>
                <span><b>Melazimi amalan zikir</b> agar jiwa sentiasa tenang dan tenteram.</span>
              </div>
            </div>
          </div>
        `
      }
    ]
  },

  // ==========================================
  // 3. BAHAGIAN AKIDAH
  // ==========================================
  {
    id: "t5-p9",
    number: 9,
    field: "akidah",
    fieldLabel: "Bahagian Akidah",
    title: "Pelajaran 9: Allah SWT Maha Mengawasi dan Maha Menyaksikan",
    summary: "Penghayatan dua Asmaul Husna: Al-Raqib (Maha Mengawasi) dan Al-Shaheed (Maha Menyaksikan), dalil naqli, bukti serta kesan beriman.",
    subtopics: [
      {
        id: "t5-p9-u1",
        badge: "UNIT 1",
        title: "Unit 1: Al-Raqib (الرَّقِيب - Allah SWT Maha Mengawasi)",
        contentHtml: `
          <!-- Maksud -->
          <div class="p-4 bg-[#1f2328] border-2 border-[#ffd447] mb-4">
            <span class="badge-tag bg-[#ffd447] text-black font-extrabold px-2 py-0.5 text-xs">1. MAKSUD AL-RAQIB</span>
            <p class="text-base text-white mt-2 leading-relaxed">
              Nama Allah SWT yang menunjukkan bahawa <b>Allah SWT Maha Mengawasi semua perbuatan dan keadaan makhluk</b>.
            </p>
          </div>

          <!-- Dalil Naqli -->
          <div class="mb-4 space-y-3">
            <h4 class="text-sm font-bold text-amber-200 uppercase tracking-wider font-mono">2. Dalil Naqli Nama Allah SWT Al-Raqib</h4>
            
            <!-- Dalil 1: Al-Quran -->
            <div class="quote">
              <span class="text-xs font-bold text-[#ffd447] uppercase block mb-1">1. Firman Allah SWT (Surah al-Ma'idah: 117):</span>
              <p class="arabic-text text-xl my-2 text-right">...فَلَمَّا تَوَفَّيْتَنِي كُنتَ أَنتَ الرَّقِيبَ عَلَيْهِمْ ۚ وَأَنتَ عَلَىٰ كُلِّ شَيْءٍ شَهِيدٌ</p>
              <p class="text-xs sm:text-sm text-amber-100/90 mt-1">
                <b>Maksud:</b> "...Kemudian apabila Engkau menyempurnakan tempohku, Engkaulah sendiri yang mengawasi keadaan mereka, dan Engkau jua yang menjadi saksi atas tiap-tiap sesuatu."
              </p>
            </div>

            <!-- Dalil 2: Hadis -->
            <div class="quote">
              <span class="text-xs font-bold text-[#ffd447] uppercase block mb-1">2. Sabda Rasulullah SAW (daripada Abdullah bin al-Samit RA):</span>
              <p class="arabic-text text-xl my-2 text-right">أَفْضَلُ الْإِيمَانِ أَنْ تَعْلَمَ أَنَّ اللَّهَ مَعَكَ حَيْثُ مَا كُنْتَ</p>
              <p class="text-xs sm:text-sm text-amber-100/90 mt-1">
                <b>Maksud:</b> "Iman yang paling afdal ialah engkau mengetahui bahawa Allah bersamamu di mana-mana jua engkau berada." <span class="text-xs text-amber-300/80">(Riwayat al-Tabarani dan Abu Nu'aim)</span>
              </p>
            </div>
          </div>

          <!-- Bukti Allah SWT Bersifat Al-Raqib -->
          <div>
            <h4 class="text-sm font-bold text-amber-200 uppercase tracking-wider font-mono mb-2">3. Bukti Allah SWT Bersifat Al-Raqib</h4>
            <div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th style="width: 8%;">Bil.</th>
                    <th style="width: 46%;">Bukti</th>
                    <th style="width: 46%;">Dalil Al-Quran</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="font-bold text-center text-[#ffd447]">1</td>
                    <td><b>Allah SWT Maha Mengawasi manusia dalam aspek kepatuhan kepada perintah dan larangan-Nya.</b></td>
                    <td>
                      <p class="arabic-text text-base my-1 text-right">وَكَانَ اللَّهُ عَلَىٰ كُلِّ شَيْءٍ رَّقِيبًا</p>
                      <p class="text-xs text-slate-300"><b>Surah al-Ahzab: 52</b> — <i>"...Dan Allah sentiasa mengawasi tiap-tiap sesuatu."</i></p>
                    </td>
                  </tr>
                  <tr>
                    <td class="font-bold text-center text-[#ffd447]">2</td>
                    <td><b>Allah SWT sentiasa mengawasi manusia dalam aspek hubungan sesama manusia.</b></td>
                    <td>
                      <p class="arabic-text text-base my-1 text-right">إِنَّ اللَّهَ كَانَ عَلَيْكُمْ رَقِيبًا</p>
                      <p class="text-xs text-slate-300"><b>Surah an-Nisa': 1</b> — <i>"...Sesungguhnya Allah sentiasa mengawasi kamu."</i></p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        `
      },
      {
        id: "t5-p9-u2",
        badge: "UNIT 2",
        title: "Unit 2: Al-Shaheed (الشَّهِيد - Allah SWT Maha Menyaksikan)",
        contentHtml: `
          <!-- Maksud -->
          <div class="p-4 bg-[#1f2328] border-2 border-[#2fd17a] mb-4">
            <span class="badge-tag bg-[#2fd17a] text-black font-extrabold px-2 py-0.5 text-xs">1. MAKSUD AL-SHAHEED</span>
            <p class="text-base text-white mt-2 leading-relaxed">
              Nama Allah SWT yang menunjukkan bahawa <b>Allah SWT Maha Menyaksikan segala perbuatan dan ucapan makhluk serta tiada sesuatu pun yang tersembunyi daripada-Nya</b>.
            </p>
          </div>

          <!-- Dalil Naqli -->
          <div class="mb-4 space-y-3">
            <h4 class="text-sm font-bold text-amber-200 uppercase tracking-wider font-mono">2. Dalil Naqli Nama Allah SWT Al-Shaheed</h4>
            
            <!-- Dalil 1: Al-Quran -->
            <div class="quote">
              <span class="text-xs font-bold text-[#2fd17a] uppercase block mb-1">1. Firman Allah SWT (Surah al-An'am: 19):</span>
              <p class="arabic-text text-xl my-2 text-right">قُلْ أَيُّ شَيْءٍ أَكْبَرُ شَهَـٰدَةً ۖ قُلِ ٱللَّهُ شَهِيدٌۢ بَيْنِي وَبَيْنَكُمْ...</p>
              <p class="text-xs sm:text-sm text-amber-100/90 mt-1">
                <b>Maksud:</b> Katakanlah, "Apakah sesuatu yang lebih besar persaksiannya?" Katakanlah, "Allah menjadi saksi antara aku dengan kamu..."
              </p>
            </div>

            <!-- Dalil 2: Hadis -->
            <div class="quote">
              <span class="text-xs font-bold text-[#2fd17a] uppercase block mb-1">2. Sabda Rasulullah SAW (daripada Abu Hurairah RA):</span>
              <p class="text-xs sm:text-sm text-amber-200/90 mb-1">Baginda menceritakan tentang seorang lelaki Bani Israil yang meminjam wang seribu dinar dan berkata:</p>
              <p class="arabic-text text-xl my-1 text-right">...كَفَىٰ بِٱللَّهِ شَهِيدًۭا...</p>
              <p class="text-xs sm:text-sm text-amber-100/90 mt-1">
                <b>Maksud:</b> "...Cukuplah Allah menjadi saksi." <span class="text-xs text-amber-300/80">(Riwayat al-Bukhari)</span>
              </p>
            </div>
          </div>

          <!-- Bukti Allah SWT Bersifat Al-Shaheed -->
          <div>
            <h4 class="text-sm font-bold text-amber-200 uppercase tracking-wider font-mono mb-2">3. Bukti Allah SWT Bersifat Al-Shaheed</h4>
            <div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th style="width: 8%;">Bil.</th>
                    <th style="width: 62%;">Bukti</th>
                    <th style="width: 30%;">Dalil Surah</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="font-bold text-center text-[#2fd17a]">1</td>
                    <td><b>Allah SWT menjadi saksi perutusan Rasulullah SAW atas umatnya.</b></td>
                    <td class="font-semibold text-amber-300">Surah al-Fath: 28</td>
                  </tr>
                  <tr>
                    <td class="font-bold text-center text-[#2fd17a]">2</td>
                    <td><b>Allah SWT Maha Menyaksikan dan menghitung segala amalan perbuatan manusia.</b></td>
                    <td class="font-semibold text-amber-300">Surah al-Mujadilah: 6</td>
                  </tr>
                  <tr>
                    <td class="font-bold text-center text-[#2fd17a]">3</td>
                    <td><b>Allah SWT sahaja yang menjadi saksi atas segala perkara yang nyata atau yang tersembunyi.</b></td>
                    <td class="font-semibold text-amber-300">Surah Fussilat: 53</td>
                  </tr>
                  <tr>
                    <td class="font-bold text-center text-[#2fd17a]">4</td>
                    <td><b>Allah SWT menjadi saksi pengakuan dusta orang-orang munafik.</b></td>
                    <td class="font-semibold text-amber-300">Surah al-Munafiqun: 1</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        `
      },
      {
        id: "t5-p9-u3",
        badge: "UNIT 3",
        title: "Unit 3: Pengajaran & Kesan Beriman dengan Al-Raqib & Al-Shaheed",
        contentHtml: `
          <div class="p-4 bg-[#1f2328] border-2 border-cyan-400">
            <span class="badge-tag bg-cyan-400 text-black font-extrabold px-2 py-0.5 text-xs">PENGHAYATAN & KESAN</span>
            <h4 class="text-base font-bold text-white mt-2 mb-3">Tiga Kesan dan Pengajaran Utama Beriman dengan Nama Allah Al-Raqib & Al-Shaheed:</h4>
            
            <div class="space-y-3">
              <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-3">
                <span class="w-6 h-6 rounded-none bg-[#ffd447] text-black font-extrabold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-[1px_1px_0_#000]">1</span>
                <div>
                  <strong class="text-white block text-sm sm:text-base">Melahirkan Rasa Waspada dan Takut Melakukan Maksiat</strong>
                  <p class="text-xs sm:text-sm text-slate-300 mt-0.5">
                    Sentiasa melahirkan rasa waspada dan takut untuk melakukan maksiat kerana meyakini Allah SWT sentiasa mengawasi dan menyaksikan setiap perbuatan, sama ada yang tersembunyi mahupun terang-terangan.
                  </p>
                </div>
              </div>

              <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-3">
                <span class="w-6 h-6 rounded-none bg-[#2fd17a] text-black font-extrabold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-[1px_1px_0_#000]">2</span>
                <div>
                  <strong class="text-white block text-sm sm:text-base">Mendorong Diri untuk Ikhlas dalam Setiap Amalan</strong>
                  <p class="text-xs sm:text-sm text-slate-300 mt-0.5">
                    Mendorong diri untuk sentiasa ikhlas dalam beribadah dan melakukan amalan soleh sama ada di hadapan orang ramai mahupun ketika bersendirian tanpa mengharapkan pujian manusia.
                  </p>
                </div>
              </div>

              <div class="p-3 bg-[#2d3036] border border-stone-600 flex items-start gap-3">
                <span class="w-6 h-6 rounded-none bg-cyan-400 text-black font-extrabold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-[1px_1px_0_#000]">3</span>
                <div>
                  <strong class="text-white block text-sm sm:text-base">Memelihara Pergaulan dan Hubungan Sesama Manusia</strong>
                  <p class="text-xs sm:text-sm text-slate-300 mt-0.5">
                    Memelihara pergaulan dan hubungan sesama manusia mengikut batasan syarak agar tidak menzalimi, menipu, atau memfitnah orang lain.
                  </p>
                </div>
              </div>
            </div>
          </div>
        `
      }
    ]
  },
  {
    id: "t5-p10",
    number: 10,
    field: "akidah",
    fieldLabel: "Bahagian Akidah",
    title: "Pelajaran 10: Akidah Ahli Sunnah Waljamaah (ASWJ)",
    summary: "Prinsip utama pegangan ASWJ, aliran bertentangan (Syiah, Khawarij, Muktazilah), dan kepentingan berpegang dengan ASWJ.",
    directContentHtml: `
      <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d] mb-4">
        <span class="field-label text-xs">PANDUAN TAJUK TINGKATAN 5</span>
        <h4 class="text-white font-bold text-base mt-2">Pelajaran 10: Akidah Ahli Sunnah Waljamaah</h4>
        <p class="text-sm text-slate-300 mt-1">Takrif ASWJ, 6 prinsip pegangan (al-Quran kalam Allah, melihat Allah di akhirat, status pelaku dosa besar), perbandingan dengan Khawarij dan Muktazilah, serta kepentingan memelihara kesucian pegangan ASWJ.</p>
      </div>
    `
  },

  // ==========================================
  // 4. BIDANG FIQAH
  // ==========================================
  {
    id: "t5-p11",
    number: 11,
    field: "fikah",
    fieldLabel: "Bidang Fiqah",
    title: "Pelajaran 11: Solat Sunat Istikharah dan Solat Sunat Tasbih",
    summary: "Kaifiat, lafaz niat, doa, dan hikmah menunaikan solat sunat Istikharah dan Tasbih.",
    subtopics: [
      {
        id: "t5-p11-u1",
        badge: "UNIT 1",
        title: "Unit 1: Solat Sunat Istikharah",
        contentHtml: `
          <div class="p-3 bg-[#1f2328] border border-stone-600">
            <p class="text-sm text-slate-300">Maksud, dalil pensyariatan, kaifiat pelaksanaan 2 rakaat, doa khas Istikharah memohon petunjuk pilihan terbaik, dan adab membuat keputusan.</p>
          </div>
        `
      },
      {
        id: "t5-p11-u2",
        badge: "UNIT 2",
        title: "Unit 2: Solat Sunat Tasbih",
        contentHtml: `
          <div class="p-3 bg-[#1f2328] border border-stone-600">
            <p class="text-sm text-slate-300">Maksud, kaifiat pelaksanaan 4 rakaat dengan 300 kali bacaan tasbih khusus dalam setiap rukun solat, serta ganjaran keampunan dosa.</p>
          </div>
        `
      }
    ]
  },
  {
    id: "t5-p12",
    number: 12,
    field: "fikah",
    fieldLabel: "Bidang Fiqah",
    title: "Pelajaran 12: Perkahwinan",
    summary: "Konsep perkahwinan dalam Islam, rukun nikah, syarat wali dan saksi, mahar, walimatulurus, serta kemahiran keibubapaan.",
    subtopics: [
      {
        id: "t5-p12-u1",
        badge: "UNIT 1",
        title: "Unit 1: Perkahwinan (Munakahat)",
        contentHtml: `
          <div class="p-3 bg-[#1f2328] border border-stone-600">
            <p class="text-sm text-slate-300">Maksud, hukum perkahwinan (harus, wajib, sunat, makruh, haram), 5 rukun nikah (suami, isteri, wali, 2 saksi, sighah), kriteria memilih pasangan, dan walimatulurus.</p>
          </div>
        `
      },
      {
        id: "t5-p12-u2",
        badge: "UNIT 2",
        title: "Unit 2: Kemahiran Keibubapaan",
        contentHtml: `
          <div class="p-3 bg-[#1f2328] border border-stone-600">
            <p class="text-sm text-slate-300">Tanggungjawab ibu bapa mendidik anak-anak dari aspek akidah, ibadah, akhlak, fizikal, dan emosi demi membina keluarga sakinah mawaddah warahmah.</p>
          </div>
        `
      }
    ]
  },
  {
    id: "t5-p13",
    number: 13,
    field: "fikah",
    fieldLabel: "Bidang Fiqah",
    title: "Pelajaran 13: Isu-Isu dalam Perkahwinan",
    summary: "Hukum dan implikasi talaq, fasakh, khul' (tebus talaq), nusyuz, li'an, iddah, ruju', poligami, dan hadanah.",
    directContentHtml: `
      <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d] mb-4">
        <span class="field-label text-xs">PANDUAN TAJUK TINGKATAN 5</span>
        <h4 class="text-white font-bold text-base mt-2">Pelajaran 13: Isu-Isu dalam Perkahwinan</h4>
        <p class="text-sm text-slate-300 mt-1">Perincian pembubaran perkahwinan: talaq raj'i & ba'in, fasakh di mahkamah syariah, khul' dengan iwad, sumpah li'an, tempoh iddah, langkah mendidik isteri nusyuz, syarat poligami adil, serta hak penjagaan anak (hadanah).</p>
      </div>
    `
  },
  {
    id: "t5-p14",
    number: 14,
    field: "fikah",
    fieldLabel: "Bidang Fiqah",
    title: "Pelajaran 14: Pengurusan Harta Selepas Kematian",
    summary: "Sistem pengurusan harta pusaka Islam merangkumi wasiat dan pembahagian faraid.",
    subtopics: [
      {
        id: "t5-p14-u1",
        badge: "UNIT 1",
        title: "Unit 1: Wasiat dalam Islam",
        contentHtml: `
          <div class="p-3 bg-[#1f2328] border border-stone-600">
            <p class="text-sm text-slate-300">Maksud wasiat, hukum, syarat sah wasiat, batas maksimum 1/3 harta kepada bukan waris faraid, dan hikmah pensyariatan wasiat.</p>
          </div>
        `
      },
      {
        id: "t5-p14-u2",
        badge: "UNIT 2",
        title: "Unit 2: Faraid dalam Islam",
        contentHtml: `
          <div class="p-3 bg-[#1f2328] border border-stone-600">
            <p class="text-sm text-slate-300">Maksud faraid, rukun dan syarat waris, golongan Ashabul Furud dan Asabah, halangan mewarisi harta, serta hikmah keadilan sistem faraid.</p>
          </div>
        `
      }
    ]
  },
  {
    id: "t5-p15",
    number: 15,
    field: "fikah",
    fieldLabel: "Bidang Fiqah",
    title: "Pelajaran 15: Jenayah dalam Islam",
    summary: "Hukum jenayah Islam: Hudud, Qisas, Diat, dan Ta'zir.",
    directContentHtml: `
      <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d] mb-4">
        <span class="field-label text-xs">PANDUAN TAJUK TINGKATAN 5</span>
        <h4 class="text-white font-bold text-base mt-2">Pelajaran 15: Jenayah dalam Islam</h4>
        <p class="text-sm text-slate-300 mt-1">Konsep keadilan undang-undang jenayah syariah, pembahagian kesalahan Hudud (zina, qazaf, minum arak, mencuri, merompak, murtad), Qisas (bunuh & cederakan), Diat (pampasan), serta Ta'zir mengikut budi bicara hakim.</p>
      </div>
    `
  },

  // ==========================================
  // 5. BIDANG SIRAH DAN TAMADUN ISLAM
  // ==========================================
  {
    id: "t5-p16",
    number: 16,
    field: "sirah",
    fieldLabel: "Bidang Sirah & Tamadun",
    title: "Pelajaran 16: Kerajaan Uthmaniyah",
    summary: "Sejarah penubuhan, khalifah terkenal (Uthman bin Ertughrul, Sultan Muhammad al-Fatih, Sultan Sulaiman al-Qanuni), faktor kegemilangan dan kemerosotan.",
    directContentHtml: `
      <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d] mb-4">
        <span class="field-label text-xs">PANDUAN TAJUK TINGKATAN 5</span>
        <h4 class="text-white font-bold text-base mt-2">Pelajaran 16: Kerajaan Uthmaniyah</h4>
        <p class="text-sm text-slate-300 mt-1">Latar belakang penubuhan berpusat di Istanbul (Turki), pembukaan kota Konstantinopel pada tahun 1453M oleh Sultan Muhammad al-Fatih, kemajuan ketenteraan Janissari, serta iktibar sejarah.</p>
      </div>
    `
  },
  {
    id: "t5-p17",
    number: 17,
    field: "sirah",
    fieldLabel: "Bidang Sirah & Tamadun",
    title: "Pelajaran 17: Keunggulan Tokoh Islam",
    summary: "Riwayat hidup, keperibadian, dan sumbangan tokoh pemikir dan pejuang Islam tersohor.",
    directContentHtml: `
      <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d] mb-4">
        <span class="field-label text-xs">PANDUAN TAJUK TINGKATAN 5</span>
        <h4 class="text-white font-bold text-base mt-2">Pelajaran 17: Keunggulan Tokoh Islam</h4>
        <p class="text-sm text-slate-300 mt-1">Keunggulan Salahuddin al-Ayyubi (pembebas Baitulmaqdis), tokoh ilmuan falsafah dan sains, serta iktibar daripada kepimpinan dan keikhlasan mereka.</p>
      </div>
    `
  },

  // ==========================================
  // 6. BIDANG AKHLAK ISLAMIYAH
  // ==========================================
  {
    id: "t5-p18",
    number: 18,
    field: "akhlak",
    fieldLabel: "Bidang Akhlak Islamiyah",
    title: "Pelajaran 18: Tawadhuk Menzahirkan Kesucian Jiwa",
    summary: "Pengertian tawadhuk (merendah diri), dalil, contoh sifat tawadhuk Rasulullah SAW, dan hikmah mengamalkannya.",
    directContentHtml: `
      <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d] mb-4">
        <span class="field-label text-xs">PANDUAN TAJUK TINGKATAN 5</span>
        <h4 class="text-white font-bold text-base mt-2">Pelajaran 18: Tawadhuk Menzahirkan Kesucian Jiwa</h4>
        <p class="text-sm text-slate-300 mt-1">Maksud tawadhuk dalam pergaulan, tutur kata, dan pakaian; teladan tawadhuk baginda SAW melayan kanak-kanak dan fakir miskin; serta perbezaan tawadhuk dengan rasa rendah diri yang negatif.</p>
      </div>
    `
  },
  {
    id: "t5-p19",
    number: 19,
    field: "akhlak",
    fieldLabel: "Bidang Akhlak Islamiyah",
    title: "Pelajaran 19: Istiqamah Jalan Menuju Mujahadah",
    summary: "Konsep istiqamah berterusan dalam ketaatan, cara memperoleh istiqamah, dan kelebihannya.",
    directContentHtml: `
      <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d] mb-4">
        <span class="field-label text-xs">PANDUAN TAJUK TINGKATAN 5</span>
        <h4 class="text-white font-bold text-base mt-2">Pelajaran 19: Istiqamah Jalan Menuju Mujahadah</h4>
        <p class="text-sm text-slate-300 mt-1">Maksud istiqamah, dalil Surah Fussilat: 30, kaedah memupuk istiqamah dalam solat dan amalan kebaikan, serta ketenangan jiwa yang dikurniakan Allah SWT.</p>
      </div>
    `
  },
  {
    id: "t5-p20",
    number: 20,
    field: "akhlak",
    fieldLabel: "Bidang Akhlak Islamiyah",
    title: "Pelajaran 20: Alam Sekitar Penenang Minda",
    summary: "Adab memelihara dan memulihara alam sekitar menurut perspektif Islam.",
    directContentHtml: `
      <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d] mb-4">
        <span class="field-label text-xs">PANDUAN TAJUK TINGKATAN 5</span>
        <h4 class="text-white font-bold text-base mt-2">Pelajaran 20: Alam Sekitar Penenang Minda</h4>
        <p class="text-sm text-slate-300 mt-1">Tanggungjawab manusia sebagai khalifah memakmurkan bumi, larangan merosakkan flora & fauna, menjaga kebersihan sumber air dan udara, serta kempen lestari alam.</p>
      </div>
    `
  },
  {
    id: "t5-p21",
    number: 21,
    field: "akhlak",
    fieldLabel: "Bidang Akhlak Islamiyah",
    title: "Pelajaran 21: Sifat Mazmumah Meracuni Hati",
    summary: "Mengenali dan merawat 10 sifat mazmumah menurut Imam al-Ghazali (riak, ujub, hasad, ghadab, dll.).",
    directContentHtml: `
      <div class="p-4 bg-[#1f2328] border-2 border-[#5e646d] mb-4">
        <span class="field-label text-xs">PANDUAN TAJUK TINGKATAN 5</span>
        <h4 class="text-white font-bold text-base mt-2">Pelajaran 21: Sifat Mazmumah Meracuni Hati</h4>
        <p class="text-sm text-slate-300 mt-1">Pengertian sifat mazmumah, 10 sifat tercela kitab Bidayatul Hidayah / Ihya' Ulumiddin, bahaya riak, ujub, dan hasad dengki, serta kaedah tazkiyatun nafs (penyucian jiwa).</p>
      </div>
    `
  }
];
