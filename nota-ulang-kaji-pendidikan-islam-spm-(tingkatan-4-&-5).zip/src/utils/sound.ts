// Audio synthesizer replicating the classic Minecraft UI button click sound effect
// Crisp mechanical wooden/stone tap with subtle pitch variation on each press

let audioCtx: AudioContext | null = null;
let soundEnabled = true;

export function isSoundEnabled(): boolean {
  return soundEnabled;
}

export function setSoundEnabled(enabled: boolean): void {
  soundEnabled = enabled;
  try {
    localStorage.setItem("pi-spm-sound-enabled", JSON.stringify(enabled));
  } catch {
    // ignore
  }
}

// Initialize sound setting from localStorage
if (typeof window !== "undefined") {
  try {
    const saved = localStorage.getItem("pi-spm-sound-enabled");
    if (saved !== null) {
      soundEnabled = JSON.parse(saved);
    }
  } catch {
    soundEnabled = true;
  }
}

function getAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume();
  }
  return audioCtx;
}

/**
 * Plays the authentic Minecraft button click sound effect
 * Pitch randomized slightly (0.94 - 1.06) like in Minecraft
 */
export function playButtonClickSound(): void {
  if (!soundEnabled) return;

  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Slight pitch randomizer like Minecraft
    const pitch = 0.94 + Math.random() * 0.12;

    // 1. Sharp initial transient / knock (filtered noise burst)
    const noiseLength = Math.floor(ctx.sampleRate * 0.015);
    const noiseBuffer = ctx.createBuffer(1, noiseLength, ctx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < noiseLength; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.0025));
    }

    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;

    const noiseFilter = ctx.createBiquadFilter();
    noiseFilter.type = "bandpass";
    noiseFilter.frequency.setValueAtTime(1600 * pitch, now);
    noiseFilter.Q.setValueAtTime(2.5, now);

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.85, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.015);

    noiseSource.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(ctx.destination);
    noiseSource.start(now);

    // 2. Resonant wooden body pop (descending pitch)
    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(650 * pitch, now);
    osc.frequency.exponentialRampToValueAtTime(110 * pitch, now + 0.045);

    oscGain.gain.setValueAtTime(0.7, now);
    oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.045);

    osc.connect(oscGain);
    oscGain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.05);

    // 3. Crisp mechanical release tap (slightly delayed micro-pulse)
    const tapOsc = ctx.createOscillator();
    const tapGain = ctx.createGain();
    tapOsc.type = "triangle";
    tapOsc.frequency.setValueAtTime(340 * pitch, now + 0.018);
    tapOsc.frequency.exponentialRampToValueAtTime(140 * pitch, now + 0.042);

    tapGain.gain.setValueAtTime(0, now);
    tapGain.gain.setValueAtTime(0.35, now + 0.018);
    tapGain.gain.exponentialRampToValueAtTime(0.001, now + 0.045);

    tapOsc.connect(tapGain);
    tapGain.connect(ctx.destination);

    tapOsc.start(now + 0.018);
    tapOsc.stop(now + 0.05);
  } catch {
    // AudioContext may require user interaction first
  }
}

// Global click event listener: plays sound on any button or role="button" or interactive link click
if (typeof window !== "undefined") {
  window.addEventListener(
    "click",
    (e: MouseEvent) => {
      const target = (e.target as HTMLElement | null)?.closest(
        "button, [role='button'], .action-btn, .nav-link, .topic-toggle, .subtopic-toggle, input[type='radio'], input[type='checkbox']"
      );
      if (target) {
        playButtonClickSound();
      }
    },
    { capture: true }
  );
}
